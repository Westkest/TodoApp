

//Define 5 classes and each should contain at least a constructor
fun main() {
    //Instantiating Class House
    println("=======HOUSE=======")
    var house1: House = House("Bungalow", "green")
    var house2: House = House("Duplex", "Yellow")
    var house3: House = House("Duplex", "green", "Nnebisi Road")
    var house4: House = House("Duplex", "white")
    var house5: House = House("Bungalow", "Pink")
    var house6: House = House("Duplex", "Indigo", "Okpanam Road")

    println("The house is a ${house1.htype} and it is painted ${house1.hcolour}")
    println("The house is a ${house2.htype} and it is painted ${house2.hcolour}")
    println("The house is a ${house3.htype} and it is painted ${house3.hcolour} and located at ${house3.haddress}")
    println("The house is a ${house4.htype} and it is painted ${house4.hcolour}")
    println("The house is a ${house5.htype} and it is painted ${house5.hcolour}")
    println("The house is a ${house6.htype} and it is painted ${house6.hcolour}and located at ${house3.haddress}")

    //Instantiating CLass School
    println("=======SCHOOL=======")
    var school1: School = School("Solid Rock", "Agbor")
    var school2: School = School("Word of Faith", "Warri")
    var school3: School = School("FLock of God", "Asaba")
    var school4: School = School("Kogbodi", "Ugheli")
    var school5: School = School("Still of Glory", "Benin City")

    println("School name is ${school1.sname} and it is located in ${school1.slocation}")
    println("School name is ${school2.sname} and it is located in ${school2.slocation}")
    println("School name is ${school3.sname} and it is located in ${school3.slocation}")
    println("School name is ${school4.sname} and it is located in ${school4.slocation}")
    println("School name is ${school5.sname} and it is located in ${school5.slocation}")

    //Instantiating Class Animal
    println("=======ANIMAL=======")
    var animal1:Animal=Animal("Dog",5,"Black and White")
    var animal2:Animal=Animal("Goat",3,"Black")
    var animal3:Animal=Animal("Fish",1,"Black")
    var animal4:Animal=Animal("Chicken",1,"Brown")
    var animal5:Animal=Animal("Pig",6,"White")

    println("The ${animal1.aname} is ${animal1.aage} and it is ${animal1.acolour} in colour")
    println("The ${animal2.aname} is ${animal1.aage} and it is ${animal1.acolour} in colour")
    println("The ${animal3.aname} is ${animal1.aage} and it is ${animal1.acolour} in colour")
    println("The ${animal4.aname} is ${animal1.aage} and it is ${animal1.acolour} in colour")
    println("The ${animal5.aname} is ${animal1.aage} and it is ${animal1.acolour} in colour")

    //Instantiating Class Person
    println("=======PERSON=======")
    var person1:Person=Person("Mike",23,"Trader")
    var person2:Person=Person("Frank",31,"Farmer")
    var person3:Person=Person("Emmanuel",40,"Banker")
    var person4:Person=Person("Collins",43,"Programmer")
    var person5:Person=Person("Angela",27,"Teacher")

    println("${person1.pname} is ${person1.page} and he is a ${person1.poccupation} ")
    println("${person2.pname} is ${person2.page} and he is a ${person2.poccupation} ")
    println("${person3.pname} is ${person3.page} and he is a ${person3.poccupation} ")
    println("${person4.pname} is ${person4.page} and he is a ${person4.poccupation} ")
    println("${person5.pname} is ${person5.page} and he is a ${person5.poccupation} ")

    //Instantiating Fruits
    println("=======FRUIT=======")
    var fruit1:Fruit=Fruit("Banana")
    var fruit2:Fruit=Fruit("Apple")
    var fruit3:Fruit=Fruit("Orange")
    var fruit4:Fruit=Fruit("Pear")
    var fruit5:Fruit=Fruit("Mango")

    println("The fruit is ${fruit1.fname}")
    println("The fruit is ${fruit2.fname}")
    println("The fruit is ${fruit3.fname}")
    println("The fruit is ${fruit4.fname}")
    println("The fruit is ${fruit5.fname}")

}


class House {
    var htype: String = ""
    var hcolour: String = ""
    var haddress: String = ""

    constructor(htype: String, hcolour: String) {
        this.htype = htype
        this.hcolour = hcolour

    }

    constructor(htype: String, hcolour: String, haddress:String) {
        this.htype = htype
        this.hcolour = hcolour
        this.haddress = haddress
    }
}

class School {
    var sname: String = ""
    var slocation: String = ""

    constructor(sname: String, slocation: String) {
        this.sname = sname
        this.slocation = slocation
    }
}

class Animal {
    var aname: String = ""
    var aage: Int = 0
    var acolour: String = ""

    constructor(aname: String, aage: Int, acolour: String) {
        this.aname = aname
        this.aage = aage
        this.acolour = acolour
    }
}

class Person {
    var pname: String = ""
    var page: Int = 0
    var poccupation: String = ""

    constructor(pname: String, page: Int, poccupation: String) {
        this.pname = pname
        this.page = page
        this.poccupation = poccupation
    }
}

class Fruit {
    var fname: String = ""

    constructor(fname: String) {
        this.fname = fname

    }
}