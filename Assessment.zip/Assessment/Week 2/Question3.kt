//Printing even numbers between 10 and 20
//print out Odd numbers between 30 and 40
fun main() {

    var i: Int = 0

    for (i in 10..30)
        if (i <= 20) {
            if (i % 2 == 0)
                println(i)


        } else {

            if (i % 2 != 0)
                println(i)
        }
}