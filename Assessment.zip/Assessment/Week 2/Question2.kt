//Loop to print 1 to 100
fun main() {
    var i: Int = 0
    for (i in i..100) {
        println(i)
    }
//loop to print 1 to 100 skipping 4 and 5
    println("===========SKIPPING 4 AND 5=============")
    var p: Int = 0
    for (p in 1..10) {
        if (p ==4 || p== 5) {
            continue
        }
        println(p)
    }
}