//Question 1: 10 If Statement
fun main() {
    var score: Int = 900
    var grade: String = ""
    if (score >= 90 && score <= 100) {
        grade = "A"
    } else if (score >= 80 && score < 90) {
        grade = "AB"
    } else if (score >= 70 && score <= 80) {
        grade = "B"
    } else if (score >= 60 && score <= 70) {
        grade = "C"
    } else if (score >= 50 && score <= 60) {
        grade = "CD"
    } else if (score >= 40 && score <= 50) {
        grade = "D"
    } else if (score >= 30 && score <= 40) {
        grade = "E"
    } else if (score >= 20 && score <= 30) {
        grade = "F"
    } else if (score >= 10 && score <= 20) {
        grade = "F"
    } else if (score >= 0 && score <= 10) {
        grade = "F"
    } else {
        grade = "Invalid"
    }
    println("YOur Score is $score and your Grade is $grade")

//5 Conditional Expresion using when statement
// code to display IHub Start up Academy Training Timetable
    var days:String = "wednesday"

    when {
        days == "monday" ->
            println("Back-End Development, Android Application Development (Class 1), Android Application Development(Class 2")
        days == "tuesday" ->
            println("Back-End Development, Android Application Development (Class 1), Android Application Development(Class 2")
        days == "wednesday" ->
            println("Back-End Development, Android Application Development (Class 1), Android Application Development(Class 2")
        days == "thursday" ->
            println("Front-End Development, UI / UX Design (Class 1), UI / UX Design (Class 2)")
        days == "friday" ->
            println("Front-End Development, UI / UX Design (Class 1), UI / UX Design (Class 2)")
        days == "saturday" ->
            println("Front-End Development, UI / UX Design (Class 1), UI / UX Design (Class 2)")

        else ->
            println("No Class for Today")

    }

}


