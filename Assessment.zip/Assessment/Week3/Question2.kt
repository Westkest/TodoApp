/*Write a short program that prints the reverse of a string that is supllied.
you can assume that the string passed will never be empty or null.
When given the string "Good food", the output should be "doof dooG".*/
fun main (){
    var str:String="Good Food"
    var  reverse: String=str.reversed()
    println("The reversal of $str is $reverse")
}z